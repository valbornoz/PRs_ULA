#include<iostream>
#include<string>
#include<stdlib.h>


using namespace std;

int main(){

	string linea;
	
	getline(cin,linea);

	cout << endl;	

	for(int i=linea.size();i>=0;i--)
		cout<<linea[i];
	
	cout << endl;

	return 0;
}
