#include<iostream>
#include<string>
#include<stdlib.h>
#include<stdio.h>

using namespace std;

int main(){

	// PRIMERA  PARTE DE LA CLASE
	// MANEJO DE CADENAS DE CARACTERES CON STRING


	string nombre, aux1, aux2, aux3;
	nombre = "hola_como_se_encuentra";
	aux1 = " ";
	aux2 = "perro";
	aux3 = nombre+aux1+aux2;

	cout <<"La suma de las 3 cadenas es: " << aux3 <<endl;
	cout <<"El largo del aux3 es: " << aux3.size()<< endl;
	cout <<"El largo del aux3 es: " << aux3.length()<< endl;

	aux2+=" gato";

	cout <<" aux2 = " << aux2 << endl;

	cout << " aux2 en la posicion 1 tiene: " <<aux2[0]<< endl;
	cout << " Borro la cadena aux2"<<endl;
	aux2.clear();

	if (aux2.empty()){
		cout<< " La cadena fue borrada exitosamente " << endl;
	
	}

	cout << " Posicion del primer caracter 'l' de la cadena nombre:  " << nombre.find_first_of("l")<<endl;
	
	cout << " Substring de la cadena nombre: " << nombre.substr(5,4)<<endl;

	aux1=aux2="iguales";

	// aux1.compare(aux2);

	if(aux1 == aux2){
		cout << "Las cadenas aux1 y aux 2 son iguales"<<endl;
	}

	
	getline(cin,nombre);

	cout << "Nombre contiene: "<<nombre<<endl;
	
	getline(cin,nombre,'f');
	cout << "Nombre contiene hasta la primera f: "<<nombre<<endl;

	nombre.clear();
	aux1.clear();
	aux2.clear();
	aux3.clear();

	

	// SEGUNDA PARTE DE LA CLASE CONVERSION DE
	// UN CARACTER (ASCII) A UN VALOR
	
	aux1= "23.45";
	aux2= "15";
	int valor1;
	float valor2,suma;

	valor1= atoi(aux2.c_str());
	valor2= atof(aux1.c_str());

	suma = valor1 + valor2;

	cout << "La suma de los dos valores es: " << atoi(aux2.c_str()) + atof(aux1.c_str()) <<endl;

	//	cout << "La suma de los dos valores es: " << suma <<endl;



	return 0;
}
