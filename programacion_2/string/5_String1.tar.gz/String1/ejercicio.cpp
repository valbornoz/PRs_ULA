#include<iostream>
#include<string>
#include<stdlib.h>


using namespace std;

int main(){

	string linea;
	int a,h,c,d;
	a=h=c=d=0;
	getline (cin,linea);

	for (int i=0; i<linea.size(); i++){
		if(linea[i]=='a')
			a++;
		if(linea[i]=='h')
			h++;
		if(linea[i]=='c')
			c++;
		if(linea[i]=='d')
			d++;
	}

	cout<< " Ultima Palabra: " << endl;	

	for(int i=linea.find_last_of(" ");i<linea.size();i++){
		cout << linea[i];
	}

	cout << endl;

	cout << "Posicion del primer espacio en blanco: " <<linea.find_first_of(" ")+1<<endl;

	cout << "Cantidades de 'a' : "<<a<<endl;
	cout << "Cantidades de 'h' : "<<h<<endl;
	cout << "Cantidades de 'c' : "<<c<<endl;
	cout << "Cantidades de 'd' : "<<d<<endl;

	return 0;
}
