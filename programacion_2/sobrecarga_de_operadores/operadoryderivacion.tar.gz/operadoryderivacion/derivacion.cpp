#include <iostream>

using namespace std;

class Pelaje
{
	private:
		int color; //SinPelo 0  Rojo 1    Verde 2    Amarillo 3   Morado 4
		
	public:
		Pelaje()
		: color(0)
		{
			//vacio	
		}

		Pelaje(int c)
		: color(c)
		{
			//vacio	
		}
		int verColor(){return color;}
		void asignarColor(int c){color = c;}
};

class Vertebrado
{
private:
	int num_patas;	
	float peso;
public:
	Vertebrado()
	: num_patas(0), peso(0.0)
	{
		//vacio	
	}

	Vertebrado(int np, float p)
	: num_patas(np), peso(p)
	{
		//vacio	
	}
	void asignarPatas(int p)
	{
		num_patas = p;
	}
	int verPatas(){ return  num_patas;}
	void asignarPeso(float p)
	{
		peso=p;
	}
	float verPeso(){	return peso; }

	
};

class Mamifero: public Vertebrado
{
private:
	int semanas_gestacion;
	
public:
	Pelaje p;
	Mamifero()
	: Vertebrado(), semanas_gestacion(0)
	{
		//vacio	
	}

	Mamifero(int np, float peso, int semanas)
	: Vertebrado(np, peso), semanas_gestacion(semanas)
	{
		//vacio	
	}
	void asignarSemanas(int s)
	{
		semanas_gestacion = s;

	}
	int verSemanas(){ return  semanas_gestacion;}
	
};


int main(){

	Vertebrado culebra;
	Mamifero perro;

	culebra.asignarPatas(0);
	culebra.asignarPeso(2);
	perro.asignarPatas(4);
	perro.asignarPeso(10);
	perro.asignarSemanas(12);
	perro.p.asignarColor(2);

	cout<<culebra.verPatas()<<endl
	<<culebra.verPeso()<<endl
	<<perro.verPatas()<<endl
	<<perro.verPeso()<<endl
	<<perro.verSemanas()<<endl
	<<perro.p.verColor()<<endl;






}
