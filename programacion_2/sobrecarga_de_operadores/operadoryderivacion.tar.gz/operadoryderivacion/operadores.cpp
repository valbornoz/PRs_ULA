#include<iostream>

class Operador{
	public:
	int a;
	int b;


	Operador(const int a,const int b){
	        this->a = a;
	        this->b = b;
	}

	Operador& operator +(const Operador &op2){
 		 return *(new Operador(op2.a + this->a, op2.b + this->b) );
	}

	Operador& operator *(const Operador &op1){
		return *(new Operador(op1.a * this->a, op1.b * this->b) );
}

	void operator =(const Operador &op1){
		this->a = op1.a;
		this->b = op1.b;
	}
};


int main(){
	Operador op1(5,8);
	Operador op2(2,7);
	Operador op3(0,0);
	op3 = op1 + op2;
	std::cout << op3.a<<" "<<op3.b<<std::endl;	
	op3 = op1;
	std::cout << op3.a<<" "<<op3.b<<std::endl;
	op3 = op1 * op2;
	std::cout << op3.a<<" "<<op3.b<<std::endl;
}
