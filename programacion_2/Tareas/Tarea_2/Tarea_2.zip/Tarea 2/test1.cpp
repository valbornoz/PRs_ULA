#include "cadena.h"

int main() {

	/*cadena p1;
	p1 = "hola";
        p1.longitud();
        p1.mostrar();
	p1.invertir();
	p1.mostrar();
	cout << endl;
	
	p1 = "cosa";
        p1.mostrar();
	!p1;
	p1.mostrar();
	cout << endl;
	
        cadena p2;
	p2 = "Problema";
	p2.mesh("Complicado");
	p2.mostrar();
	cout << endl;

	p2 = "Hola";
	p2 *= "Casa";
	p2.mostrar();
	cout << endl;*/
        
	cadena c1="facultad";
	c1.capital("facultad");
	c1.mostrar();
	cout<<endl;

	/*cadena c1="facultad";
	--c1;
	c1.mostrar();
	cout<<endl;*/
}
