#include <string>
#include <iostream>

using namespace std;

	class Vehiculo{

		public:
        void setOcupado(int o){
            ocupado=o;
        }
		void setName(string name){
			nombre=name;
		}

		void setCodigo(int code){
			codigo=code;
		}
		void setMarca(string marc){
			marca=marc;
		}
		void setAnyo(int an){
			a=an;
		}
		void setModelo(string model){
			modelo=model;
		}
        int getOcupado(){
            return ocupado;
        }
		string getName(){
			return nombre;
		}

		string getModelo(){
			return modelo;
		}
		int getCodigo(){
			return codigo;
		}
		string getMarca(){
			return marca;
		}
		int getAnyo(){
			return a;
		}

		void LeerDatos(){


				cout<<"************************"<<endl;
				cout<<" IngresarDatosRepuesto  "<<endl;
				cout<<"************************"<<endl;

			cout<<"Ingresar Nombre: "<<endl;
			getline(cin, nombre);
			cout<<"Ingresar Marca: "<<endl;
			getline(cin, marca);
			cout<<"Ingresar Modelo: "<<endl;
			getline(cin, modelo);
			cout<<"Ingresar año: "<<endl;
			cin>>a;
			cout<<"Ingresar Codigo del carro: "<<endl;
			cin>>codigo;
			cin.ignore();
		}

		void MostrarDatos(){

				cout<<"****************"<<endl;
				cout<<"  MostrarDatos  "<<endl;
				cout<<"****************"<<endl;
			cout<<"Nombre: "<<nombre<<endl;
			cout<<"Marca: "<<marca<<endl;
			cout<<"Modelo: "<<modelo<<endl;
			cout<<"año: "<<a<<endl;
			cout<<"Codigo: "<<codigo<<endl;
		}


		void repetidos(int *arreglo, int &e){
			int j,p=0;
			bool repetido;
				for(int i=0;i<e/5;i++){
			  		repetido=false;
						for(j=0;j<p;j++){
							 if(arreglo[i]=arreglo[j]){
								repetido=true;
							  }
						}
				if(repetido=true){
					arreglo[p+1]=arreglo[i];
				}
				cout<<arreglo[i]<<endl;
				}
		}


		private:

		int codigo,a, ocupado;
		string nombre,modelo,marca;
	};






