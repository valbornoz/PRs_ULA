#include "vehiculo.h"
#include <iostream>
#include <fstream>


	int main(){
			Vehiculo v;

			ifstream ae;
			ofstream as;
		as.open("repuestos.txt", ios::out | ios::app);

		int op=1;
		while(op){

			v.LeerDatos();
			as<<v.getName()<<endl;
			as<<v.getModelo()<<endl;
			as<<v.getMarca()<<endl;
			as<<v.getCodigo()<<endl;
			as<<v.getAnyo()<<endl;
			cout<<"Necesita otro repuesto(si=1,no=0): "<<endl;
			cin>>op;
			cin.ignore();
		}
		as.close();

		ae.open("repuestos.txt", ios::in);
		ae.seekg(0,ios::beg);
		int e=0;
		string aux;
			while(!ae.fail()){
				getline(ae,aux);
					if(!ae.fail())
							e++;
		}

		ae.clear();
		ae.seekg(0,ios::beg);
		string a;
		int b;
		Vehiculo *V= new Vehiculo[e];
			for(int i=0; i<e/5; i++){
				ae>>a;
				V[i].setName(a);
				ae>>a;
				V[i].setModelo(a);
				ae>>a;
				V[i].setMarca(a);
				ae>>b;
				V[i].setCodigo(b);
				ae>>b;
				V[i].setAnyo(b);
			}
        ae.close();

		Vehiculo auxV[e/5];
        int k=0;
		for(int i=0;i<(e/5)-1;i++){
		    if (V[i].getOcupado() == 1 ) i++;
			for(int j=i+1;j<e/5 && i<((e/5)-1);j++){
				if(V[i].getCodigo() == V[j].getCodigo()){
					V[j].setOcupado(1);
					auxV[k].setName(V[j].getName());
					auxV[k].setModelo(V[j].getModelo());
					auxV[k].setMarca(V[j].getMarca());
					auxV[k].setCodigo(V[j].getCodigo());
					auxV[k].setAnyo(V[j].getAnyo());

					k++;

				}
				}
            }

        as.open("repetidos.txt", ios::out);
			cout<<"***********************************************"<<endl;
			cout<<"DATOS EN EL ARCHIVO CREADO PARA LOS REPETIDOS: "<<endl;
			cout<<"***********************************************"<<endl;
		for(int i=0;i<k;i++){
            auxV[i].MostrarDatos();
            as<<auxV[i].getName()<<endl;
			as<<auxV[i].getModelo()<<endl;
			as<<auxV[i].getMarca()<<endl;
			as<<auxV[i].getCodigo()<<endl;
			as<<auxV[i].getAnyo()<<endl;
		}
        as.close();

        as.open("repuestos.txt", ios::out);

		for(int i=0;i<(e/5);i++){
            if (!V[i].getOcupado()){
                as<<V[i].getName()<<endl;
                as<<V[i].getModelo()<<endl;
                as<<V[i].getMarca()<<endl;
                as<<V[i].getCodigo()<<endl;
                as<<V[i].getAnyo()<<endl;
            }
		}
        as.close();




	return 0;
	}
