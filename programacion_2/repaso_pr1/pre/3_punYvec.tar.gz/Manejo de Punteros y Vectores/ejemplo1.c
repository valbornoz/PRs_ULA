#include <stdio.h>
int main() {
   printf("El tamaño de char (caracter), es: %d\n", sizeof(char)); 
   printf("El tamaño de short (entero corto), es: %d\n", sizeof(short)); 
   printf("El tamaño de int (entero), es: %d\n", sizeof(int)); 
   printf("El tamaño de long (entero largo), es: %d\n", sizeof(long)); 
   printf("El tamaño de float (punto flotante), es: %d\n", sizeof(float)); 
   printf("El tamaño de double (doble precisión largo), es: %d\n", sizeof(double)); 

   printf("Punteros:\n");
    printf("El tamaño de un puntero a char (caracter), es: %d\n", sizeof(char *)); 
   printf("El tamaño de un puntero a short (entero corto), es: %d\n", sizeof(short *)); 
   printf("El tamaño de un puntero a int (entero), es: %d\n", sizeof(int *)); 
   printf("El tamaño de un puntero a long (entero largo), es: %d\n", sizeof(long *)); 
   printf("El tamaño de un puntero a float (punto flotante), es: %d\n", sizeof(float *)); 
   printf("El tamaño de un puntero a double (doble precisión largo), es: %d\n", sizeof(double *)); 
}
/**
 * El tamaño de char (caracter), es: 1
El tamaño de short (entero corto), es: 2
El tamaño de int (entero), es: 4
El tamaño de long (entero largo), es: 4
El tamaño de float (punto flotante), es: 4
El tamaño de double (doble precisión largo), es: 8
Punteros:
El tamaño de un puntero a char (caracter), es: 4
El tamaño de un puntero a short (entero corto), es: 4
El tamaño de un puntero a int (entero), es: 4
El tamaño de un puntero a long (entero largo), es: 4
El tamaño de un puntero a float (punto flotante), es: 4
El tamaño de un puntero a double (doble precisión largo), es: 4
*/

