#include <stdio.h> 
int main(void) { 
   int i; 
   int mi_arreglo[] = {1,23,17,4,-5,100}; 
   int *ptr; 

/* apuntamos nuestro puntero al primer elemento del arreglo*/
   ptr = &mi_arreglo[0];

   printf("Antes de introducir el valor de i observe");
   printf(" el código de las siguientes lineas\n\n");
   printf("¿Qué ocurrre cuando i toma una valor >= 6?\n\n");

   i = 0;
   while ( i >= 0 ){
     printf("Introduzca el valor de i: ");
     scanf("%d", &i);
     printf("\n"); 
     printf("mi_arreglo[%d] = %d\n", i, mi_arreglo[i]); 
     printf("*(ptr + %d) = %d\n",i, *(ptr + i)); 
     printf("*(ptr++) = %d\n", *(ptr++)); 
     printf("*(++ptr) = %d\n\n", *(++ptr)); 
   
   }
     
   return 0;
}

