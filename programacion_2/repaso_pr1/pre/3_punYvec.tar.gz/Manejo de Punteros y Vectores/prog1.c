#include <stdio.h>
#define n 5
int main ()
{
int V[n], i, md, cn;
//Entrada de datos
	for (i=0;i<n;i++)
	{
		printf ("Indique la nota numero %d \n", i+1); scanf ("%d", &V[i]);	
	}
	cn=0;	
	for (i=0;i<n;i++)
	{
		cn=cn+V[i];
	}
	md=cn/n;
//Salida de datos
	for (i=0;i<=n;i++)
	{
		printf ("La nota numero %d es igual a = %d \n", i+1, V[i]);
		printf ("El promedio de las notas del curso es = %d \n", md);
	}
 return 0;
}
