/* Program 1.1 from PTRTUT10.TXT */
#include <stdio.h> 
int j, k; 
int *ptr; 
int main (void) { 
   j = 1; 
   k = 2; 
   ptr = &k; 
   printf("\n"); 
   printf("j tiene el valor: %d y esta alojado en: %p\n", j, (void *)&j); 
   printf("k tiene el valor: %d y esta alojado en: %p\n", k, (void *)&k); 
   printf("ptr tiene el valor: %p y esta alojado en: %p\n", ptr, (void *)&ptr); 
   printf("el valor que apunta ptr es: %d\n", *ptr); 

   return(0);
}

/**
 *
j tiene el valor: 1 y esta alojado en: 0x804a028
k tiene el valor: 2 y esta alojado en: 0x804a020
ptr tiene el valor: 0x804a020 y esta alojado en: 0x804a024
el valor que apunta ptr es: 2
*/
