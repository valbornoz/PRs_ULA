#include <iostream> //biblioteca de flujos de entrada y salida

using namespace std;

int main(){

	int a, b, c;
	
	float d[10];
	int j=10;
	for(int i=0;i<10;i++){
		
		d[j-1]=i;
		j--;
	}
	for(int i=0;i<10;i++){
		cout<<d[i]<<endl;
	}
	
	return 0;
}


