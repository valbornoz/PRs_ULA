#include <iostream> //biblioteca de flujos de entrada y salida

using namespace std;

int main(){

	int *a;
	int b=10;
	float c=1.88;
	a=&b;
	std::cout<<a<<std::endl; //valor de a (apuntador)
	cout<<*a<<endl;	//contenido almacenado en la direccion en la que apunta a
	cout<<&a<<endl;// direccion de memoria donde esta almacenado a
	cout<<b<<endl; // valor de b
	cout<<&b<<endl; //direccion de memoria de b
	cout<<c<<endl;	//valor de c
	cout<<&c<<endl; //direccion de memoria de c
	
	return 0;

}
