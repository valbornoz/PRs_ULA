# mines-solver

This is a fun solver for the mines game. This was designed to be solved by
the students of the course Programación 3 at Universidad de Los Andes, Mérida,
Venezuela.