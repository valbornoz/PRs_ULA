#include "Dnode.h"

Dnode::Dnode()
{
    //ctor
}

Dnode::~Dnode()
{
    //dtor
}
