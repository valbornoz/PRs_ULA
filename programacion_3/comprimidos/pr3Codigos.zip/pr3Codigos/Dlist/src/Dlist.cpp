#include "Dlist.h"

Dlist::Dlist()
{
    //ctor
}

Dlist::~Dlist()
{
    //dtor
}
