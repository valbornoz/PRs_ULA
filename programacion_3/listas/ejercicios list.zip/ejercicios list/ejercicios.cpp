#include <iostream>
#include "sList.h"
#include "sNode.h"

using namespace std;

void leerListas(Slist<int>& lista){

		sNode<int> *nod;		
		int valor;

		cout<<"ingrese el valor"<<endl;
		cin>>valor;

		while(valor!=255){
			nod=new sNode<int>(valor);
			if(nod!=NULL)
				lista.insertFirst(nod);
			cout<<"ingrese el valor"<<endl;
			cin>>valor;
		}

return;

}

void diferencia(Slist<int>& l1, Slist<int>& l2){

Slist<int>::Iterator IT2(l2);

	
	sNode<int> *aux, *aux1;

	while(IT2.hasCurrent()){
	
		int valor=IT2.getCurrent()->getData();
		aux=l1.getFirst();
		aux1=NULL;

		while(aux->getNext()!= l1.getFirst()){
			if(valor==aux->getData()){
				if(aux1==NULL)
					l1.removeFirst();
				else
					aux1->removeNext();
			break;
			}
		aux1=aux;
		aux=aux->getNext();
		}
		IT2.next();

	}

	return;

};


bool isDisjoint(Slist<int> &l1, Slist<int> &l2){

	bool eval=true;

return eval;

};


void escribir(Slist<int>& l1){

	sNode<int> *nod;
	Slist<int>::Iterator it(l1);

		/*nod=l1.getFirst();
		while(nod->getNext()!=l1.getFirst()){
		*/
		for (;it.hasCurrent();it.next())
			cout<<it.getCurrent()->getData()<<" , "<<endl;
		//	nod=nod->getNext();		
		//}
		cout<<endl;

};


int main(){


Slist<int> l1;
Slist<int> l2;

cout<<"Leyendo l1"<<endl;

leerListas(l1);

cout<<"Leyendo l2"<<endl;

leerListas(l2);

cout<<""<<endl;

diferencia(l1, l2);
/*

Slist<int>::Iterator it(l1);

		/*nod=l1.getFirst();
		while(nod->getNext()!=l1.getFirst()){
		*/
		for (;it.hasCurrent();it.next())
			cout<<it.getCurrent()->getData()<<" , "<<endl;
		//	nod=nod->getNext();		
		//}
		cout<<endl;


escribir(l1);

/*
	if(isDisjoint(l1, l2))
		cout<<"L1 y L2 son disjuntas"<<endl;
	else
		cout<<"L1 y L2 NO SON disjuntas"<<endl;
		
*/


return 0;
}








