#ifndef BINBUSTREE_H_INCLUDED
#define BINBUSTREE_H_INCLUDED
#include "binTree.h"
#include "binNode.h"


template <class T>
class BinBusTree: public BinTree<T> {


    public:
        BinBusTree(){}
        ~BinBusTree(){}

        BinNode<T>* searchABB(T cl){

            BinNode<T>* nodAux;

            nodAux=NULL;
            if (BinTree<T>::root==0) return nodAux;

            nodAux=BinTree<T>::root;
            while (nodAux!=NULL){
                if (KEY(nodAux)==cl) return nodAux;
                if (cl<KEY(nodAux))
                    nodAux=LLINK(nodAux);
                else
                    nodAux=RLINK(nodAux);
            }
            return nodAux;
        }

        BinNode<T>* searchABBMen(T cl,BinNode<T>*& parent){

            BinNode<T>* nodAux;

            nodAux=NULL;
            parent=NULL;
            if (BinTree<T>::root==0) return nodAux;
            nodAux=BinTree<T>::root;
            while (nodAux!=NULL){
                if (KEY(nodAux)==cl) return nodAux;
                parent=nodAux;
                if (cl<KEY(nodAux))
                    nodAux=LLINK(nodAux);
                else
                    nodAux=RLINK(nodAux);
            }
            return nodAux;
        }

        bool insertABB(BinNode<T>* nod){

            BinNode<T>* pp=NULL;
            BinNode<T>* p;

            if (BinTree<T>::root == 0) {
                BinTree<T>::root=nod;
                return true;
            }
            p=searchABBMen(KEY(nod),pp);
            if (p != NULL)  return false;
            if (KEY(pp)>KEY(nod))
                LLINK(pp)=nod;
            else
                RLINK(pp)=nod;
            return true;
        }


};

#endif // BINBUSTREE_H_INCLUDED
