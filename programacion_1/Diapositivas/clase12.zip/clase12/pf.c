#include "stdio.h"

int cuadrado(int a);

void main() {
   int a,c;
   printf("Introduzca un número: ");
   scanf("%i",&a);
   
   c = cuadrado(a);   
   printf("%i al cuadrado es %i\n",a,c);
}

int cuadrado(int a) {
   int c=a*a;
   a=7;
   return c;
}


