#include "stdio.h"

main() {
   int i=0;

   while(i<100) {
      printf("%d - 1001\n",i+1);
      i = i + 1;
   }
}
