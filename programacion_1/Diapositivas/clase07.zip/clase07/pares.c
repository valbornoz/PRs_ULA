#include "stdio.h"

main() {
   int i=1002;

   while(i<=2000) {
      printf("%d\n",i);
      i = i + 2;
   }
}
/*
   int i=1000;
   while(i<=2000) {
      if(i%2==0)
         printf("%d\n",i);
      i = i + 1;
   }
*/
