#include "stdio.h"

main() {
   int a,f=1,i=1;
   
   printf("Número: ");
   scanf("%i",&a);
   
   while(i<=a) {
      f=f*i;
      i=i+1;
   }
   
   if(a>=0)
      printf("Factorial(%i)= %i\n\n", a,f);
}
