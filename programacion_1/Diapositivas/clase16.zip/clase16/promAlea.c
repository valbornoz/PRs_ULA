#include "stdio.h"

int main() {
     printf("Hola\n");
     system("pause");
     return 0;
}
