/*
Hacer un programa que calcule el promedio de cierta cantidad de
números introducidos por el usuario.
*/

#include "stdio.h"

main() {
   int   n=0;
   float suma=0.0,
         nAux;
   char  resp;
   
   do{
      printf("Nro. %i: ",n+1);
      scanf("%f",&nAux);
      suma = suma + nAux;

      getchar();
      printf("Presione 'N' para salir: ");
      scanf("%c",&resp);
      
      n=n+1;
   } while ((resp!='N')&&(resp!='n'));
   
   printf("Promedio: %.2f\n",suma/n);
}
