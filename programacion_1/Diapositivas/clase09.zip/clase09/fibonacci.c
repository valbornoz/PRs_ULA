/*
Escribir un programa en lenguaje C que calcule e imprima cierta cantidad
(Introducida por el usuario) de números de la serie de Fibonacci.
La serie de Fibonacci es: 0,1,1,2,3,5,8,13,...; y está dado por la fórmula
siguiente:
F(0) = 0
F(1) = 1
F(2) = F(0) + F(1)
...
F(n) = F(n-1) + F(n-2), para n >1
*/

#include "stdio.h"

main() {
   int n,i,f_1=1,f_2=0,f;
   
   printf("* * * SERIE DE FIBONACCI * * *\n");
   printf("Cuántos números desea mostrar?: ");
   scanf("%i",&n);
   
   if(n>=1)
      printf("0 ");
   if(n>=2)
      printf("1 ");
   for(i=2;i<=n;i++){
      f=f_1+f_2;
      printf("%i ",f);
      
      f_2=f_1;
      f_1=f;
   }
   printf("\n");
}
