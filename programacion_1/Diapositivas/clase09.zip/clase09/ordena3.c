/*
Escribir un programa en lenguaje C que, dado tres números enteros,
introducidos por teclado, muestre estos tres números ordenados de
mayor a menor.
*/
#include "stdio.h"

main() {
   float a,b,c;
   
   printf("Introduzca los tres números (a,b y c): ");
   scanf("%f %f %f",&a,&b,&c);
   if((a>=b)&&(a>=c)) {
      printf("%.2f ",a);
      if (b>=c) {
         printf("%.2f ",b);
         printf("%.2f ",c);
      } else {
         printf("%.2f ",c);
         printf("%.2f ",b);      
      }
   } else if((b>=a)&&(b>=c)) {
      printf("%.2f ",b);
      if (a>=c) {
         printf("%.2f ",a);
         printf("%.2f ",c);
      } else {
         printf("%.2f ",c);
         printf("%.2f ",a);      
      }   
   } else {
      printf("%.2f ",c);
      if (a>=b) {
         printf("%.2f ",a);
         printf("%.2f ",b);
      } else {
         printf("%.2f ",b);
         printf("%.2f ",a);      
      }   
   }
   printf("\n");      
}
