#include "stdio.h"

void main() {
   printf("Hola!!\n");
}
