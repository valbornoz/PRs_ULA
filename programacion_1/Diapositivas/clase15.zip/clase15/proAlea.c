#include "stdio.h"
#include <stdlib.h>

void main() {
   srand(time(NULL));
   int a = rand();
   
   printf("Número aleatorio: %i\n",a);
}
