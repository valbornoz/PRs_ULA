#include "stdio.h"

void main() {
   int nota;
   
   printf("Introduzca la nota: ");
   scanf("%i",&nota);
   
   switch(nota) {
      case 0: case 1: case 2: case 3: case 4: case 5: 
      	printf("Nota Pésima\n");
      	break;
      case 6: case 7: case 8: case 9: 
      	printf("Nota Mala\n");
      	break;
      case 10: case 11: case 12: case 13: 
      	printf("Nota Regular\n");
      	break;
      case 14: case 15: case 16: case 17: 
      	printf("Nota Buena\n");
      	break;
      case 18: case 19: case 20: 
      	printf("Nota Excelente\n");
      	break;      	      
      default:
         printf("Valor inválido!\n");
   }
}
