#include "stdio.h"

void main() {
   int nf,nc;
   int i,j;
   
   float A[10][10],B[10][10],R[10][10];

   printf("Introduzca la cantidad de filas y columnas: ");
   scanf("%i %i",&nf,&nc);
   
   if(nf<1||nf>10||nc<1||nf>10) {
   	printf("Error: Número de filas o columnas inválido. Rango válido: 1-10.\n");
   	return;
   }
  
  	printf("M a t r i z   A\n");
   for(i=0;i<nf;i++) {
   	for(j=0;j<nc;j++) {
   		printf("Fila %i, Columna %i:",i+1,j+1);
   		scanf("%f",&A[i][j]);
   	}
   }
   printf("\n");
   printf("M a t r i z   B\n");
   for(i=0;i<nf;i++) {
   	for(j=0;j<nc;j++) {
   		printf("Fila %i, Columna %i:",i+1,j+1);
   		scanf("%f",&B[i][j]);
   		R[i][j]=A[i][j]+B[i][j];
   	}
   }
   printf("\n");
  	printf("M A T R I Z   R E S U L T A N T E\n");
   for(i=0;i<nf;i++) {
   	for(j=0;j<nc;j++) {
   		printf("%.2f\t",R[i][j]);
   	}
   	printf("\n");
   }   
   printf("\n");
}
