#include "stdio.h"

main() {
   int a,b,R;

   printf ("Introduzca el primer número: ");
   scanf("%i",&a);
   printf ("Introduzca el segundo número: ");
   scanf("%i",&b);
   R=a+b;
   printf ("El resultado de suma %i + %i es: %i\n",a,b,R);
}
