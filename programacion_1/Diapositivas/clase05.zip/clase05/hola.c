#include "stdio.h"

main() {
   int a,b;

   printf("Numero 1: ");
   scanf("%i",&a);
   printf("Numero 1: ");
   scanf("%i",&b);
   printf("Resultado = %i\n",a+b);
}
