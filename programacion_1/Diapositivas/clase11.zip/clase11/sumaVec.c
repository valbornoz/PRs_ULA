#include "stdio.h"

main() {
   int v1[5], v2[5];
   int i;
   
   printf("Introduzca los 5 elementos del 1er vector: ");
   scanf("%i %i %i %i %i",&v1[0],&v1[1],&v1[2],&v1[3],&v1[4]);
   
   printf("Introduzca los 5 elementos del 2do vector: ");
   scanf("%i %i %i %i %i",&v2[0],&v2[1],&v2[2],&v2[3],&v2[4]);
   
   //Suma y presentación de los resultados
   printf("SUMA:\n");
   for(i=0;i<5;i++) {
   	printf("%i ",v1[i]+v2[i]);
   }
   printf("\n");
}
