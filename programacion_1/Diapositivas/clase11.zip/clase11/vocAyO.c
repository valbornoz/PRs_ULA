#include "stdio.h"

main() {
   int i=0,a=0,o=0;
   char p[20];
   
   printf("Introduzca una palabra: ");
   scanf("%s",p);
   
   while((p[i]!='\0')&&(i<20)) {
      if((p[i]=='a')||(p[i]=='A'))
         a++;
      if((p[i]=='o')||(p[i]=='O'))
         o++;         
      i++;
   }
   printf("%s tiene %i letras a y %i letras o\n",p,a,o);
}
