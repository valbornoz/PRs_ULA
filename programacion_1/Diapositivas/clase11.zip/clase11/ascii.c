#include "stdio.h"

main() {
   int i;
   
   for(i=35;i<127;i++) {
      printf("Pos:%i,Car:%c\t",i,i);
      if(i%5==0) printf("\n");
   }
}
