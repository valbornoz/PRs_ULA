#include "stdio.h"

main() {
   int n=0,i=0;
   char p[20];
   
   printf("Introduzca una palabra: ");
   scanf("%s",p);
   //Conteo de la cantidad de letras de la palabra
   while((n<20)&&(p[n]!='\0'))
   	n++;
   	
   //Impresión al revés
   i=n-1;
   printf("%s al revés, se escribe: ",p);
   while(i>=0) {
   	printf("%c",p[i]);       
      i=i-1;
   }
   printf("\n");
}
