#include "stdio.h"

main() {
   int i=0;
   char p[20];
   
   printf("Introduzca una palabra: ");
   scanf("%s",p);
   for(i=0;i<20;i++) {
      if(p[i]=='\0')
         break;
   }
         
   /*
   while((p[i]!='\0')&&(i<20))
      i++;*/
   printf("La palabra tiene %i letras\n",i);
}
