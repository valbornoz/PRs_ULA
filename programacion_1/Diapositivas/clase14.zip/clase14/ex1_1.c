/*
1. Realizar un programa en lenguaje C, que contenga y haga uso de una función que muestre los n primeros números de la siguiente serie matemática  (7 PUNTOS): 
    0, 1, 2, 5, 20, 25, 150, 157, 1256, 1265, 12650, ...
    La función debe imprimir los n primeros valores de la serie (n es pasado como parámetro). Es decir, n no es un límite de valor, sino la cantidad de números de la serie a mostrar.
    Una secuencia de cálculo para esta serie, se muestra a continuación:
	n1 = 	    0
	n2 = n1 + 1
	n3 = n2 * 2
	n4 = n3 + 3
	n5 = n4 * 4
	n6 = n5 + 5
	n7 = n6 * 6
	n8 = n7 + 7
	. . .
*/
#include "stdio.h"

void serie(int n) {
	int i,nx;
	
	for(i=0;i<n;i++) {
		
	}
}

void main() {
   int n;
   
   printf("Cuántos números desea mostrar? ");
   scanf("%i",&n);
   
   serie(n);
}

