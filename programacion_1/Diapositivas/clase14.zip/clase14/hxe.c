/*
Escribir un programa en lenguaje que solicite y almacene en vectores las edades 
y cantidad de hijos de los empleados de una empresa. El programa debe mostrar:
- La cantidad de empleados que tienen más de 40 años y no tienen hijos. 
- La cantidad de empleados que tienen como máximo 25 años y tienen 2 ó más hijos.
*/
#include "stdio.h"

void main() {
   int vEdad[20];
   int vNroHijos[20];   
   int i,n;
   int cond1=0,cond2=0;
   
   printf("Número de Empleados a registrar?: ");
   scanf("%i",&n);
   
   if((n<1)||(n>20)) {
      printf("Error: Introdujo un número inválido de empleados.");
      return;
   }
   
   //Lectura de los datos
   for(i=0;i<n;i++){
   	printf("Para el empleado %i, introduzca:\n",i+1);
   	printf("Edad: ");
   	scanf("%i",&vEdad[i]);
   	printf("Nro. de hijos: ");
   	scanf("%i",&vNroHijos[i]);
   	printf("\n");
   	
   	//Conteo de lo empleados que cumplen las condiciones
   	if((vEdad[i]>40)&&(vNroHijos[i]==0))
   		cond1=cond1+1;
   	if((vEdad[i]<=25)&&(vNroHijos[i]>=2))
   		cond2=cond2+1;
   }

 	//Visualización de resultados
 	printf("Número de empleados que tienen más de 40 años y no tienen hijos: %i\n",cond1);  
 	printf("Número de empleados que tienen como máximo 25 años y tienen 2 ó más hijos: %i\n\n",cond2);  
}
