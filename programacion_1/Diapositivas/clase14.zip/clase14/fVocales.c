/*
Escribir un programa en lenguaje que contenga y utilice una función que reciba 
(Como parámetro) una cadena de caracteres y sea capaz de retornar la cantidad 
de vocales (Sin acentuar) que contiene la cadena. 
*/
#include "stdio.h"

int ctaVocales(char texto[20]) {
	int i=0,n=0;
	while((texto[i]!='\0')&&(i<20)) {
		if((texto[i]=='a')||(texto[i]=='e')||(texto[i]=='i')||(texto[i]=='o')||(texto[i]=='u')||\
		   (texto[i]=='A')||(texto[i]=='E')||(texto[i]=='I')||(texto[i]=='O')||(texto[i]=='U'))
		   n=n+1;
		i=i+1;
	}
	return n;
}

void main() {
   char palabra[20];
   int n;
   
   printf("Escriba una palabra: ");
   scanf("%s",palabra);
   
   n=ctaVocales(palabra);
   
	printf("La palabra \"%s\" tiene %i vocales.\n\n",palabra,n);   	 	
}
