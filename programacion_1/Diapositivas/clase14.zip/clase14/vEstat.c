/*
Escribir un programa en lenguaje C que solicite una serie de números enteros, los almacene 
en un arreglo (vector) y halle el máximo, el mínimo y el promedio de estos números.
*/
#include "stdio.h"

void main() {
   int v[20];
   int i,n,max,min;
   float pro;
   
   printf("Número de elementos?: ");
   scanf("%i",&n);
   
   if((n<1)||(n>20)) {
      printf("Error: Introdujo un número inválido de elementos.");
      return;
   }
   
   //Lectura de los elementos del vector
   for(i=0;i<n;i++){
   	printf("Elemento %i/%i: ",i+1,n);
   	scanf("%i",&v[i]);
   }
   
   //Cálculo del máximo, mínimo y promedio
   max = min = pro = v[0];
   for(i=1;i<n;i++){
		if(v[i]>max)
			max=v[i];
		if(v[i]<min)
			min=v[i];
		pro=v[i]+pro;
   }
   pro=(float)pro/n;
 
 	//Visualización de resultados
 	printf("Máximo: %i\n",max);  
 	printf("Mínimo: %i\n",min);  
 	printf("Promedio: %.2f\n\n",pro);   	 	
}
