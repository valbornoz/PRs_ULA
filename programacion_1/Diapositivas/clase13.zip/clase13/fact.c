#include "stdio.h"

int fact(int x) {
	int f=1;
	for(f=1;x>=1;x--)
		f=f*x;
	return f;
}

void main() {
   int a,r;
   
   printf("Número: ");
   scanf("%i",&a);   
   
   r=fact(a);
   printf("Factorial(%i)=%i\n",a,r);
}
