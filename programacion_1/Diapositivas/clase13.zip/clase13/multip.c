#include "stdio.h"

int mul(int x, int y) {
	int r;
	r=x*y;
	return r;
}

void main() {
   int a,b,r;
   
   printf("Multiplicando: ");
   scanf("%i",&a);
   printf("Multiplicador: ");
   scanf("%i",&b);   
   
   r=mul(a,b);
   printf("%i*%i=%i\n",a,b,r);
}
