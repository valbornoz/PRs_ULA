#include "stdio.h"

main() {
   int edad;

   printf("Introduzca la edad: ");
   scanf("%i",&edad);

   if ((edad>=0)&&(edad<=2)) {
      printf("La edad corresponde a un bebé.\n");
      printf("La edad introducida fue %i.\n",edad);
   } else 
      if ((edad>=3)&&(edad<=12)) {
         printf("La edad corresponde a un niño.\n");
      } else 
         if ((edad>=13)&&(edad<=17)) {
            printf("La edad corresponde a un adolescente.\n");
         } else 
            if ((edad>=18)&&(edad<=64)) {
               printf("La edad corresponde a un adulto.\n");
            } else if ((edad>=65)&&(edad<=115)) {
               printf("La edad corresponde a un anciano.\n");
            } else
               printf("Edad fuera de rango.\n");
}
