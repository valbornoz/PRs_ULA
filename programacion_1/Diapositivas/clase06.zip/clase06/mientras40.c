#include "stdio.h"

main() {
   int i=0;

   while(i<40) {
      printf("Error!");
      i=i+1;
   }
   printf("\n");
}
