#include "stdio.h"

main() {
   char nombre[20];

   printf("Introduzca su nombre: ");
   scanf("%s",nombre);
   printf("Bienvenido %s\n", nombre);
}
