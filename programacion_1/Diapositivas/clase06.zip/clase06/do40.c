#include "stdio.h"

main() {
   int i=0;

   do {
      printf("Error!");
      i=i+1;
   } while(i<40);

   printf("\n");
}
