#include "stdio.h"

main() {
   int b,e,f=1,i=0;
   
   printf("Base: ");
   scanf("%i",&b);
   printf("Exponente: ");
   scanf("%i",&e);
   
   while(i<e) {
      f=f*b;
      printf("f=%i, b=%i\n",f,b);
      i=i+1;
   }
   
   printf("%i^%i=%i\n", b,e,f);
}
