#include "stdio.h"

main() {
   int alto, i=0, j, ancho;
   
   printf("Altura de la pirámide?: ");
   scanf("%i",&alto);

   ancho = 2*alto-1;
   while(i<alto) {
      j=0;
      while(j<ancho) {
         if((j>=(alto-i-1))&&(j<=(alto+i-1)))
            printf("*");
         else
            printf(" ");
         j=j+1;         
      }
      printf("\n");
      i=i+1;
   }
}
