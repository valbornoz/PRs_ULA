#include "stdio.h"

main() {
   int a,i=0,j=0;
   
   printf("# de asteriscos por lado?: ");
   scanf("%i",&a);
   
   while(i<a) {
      j=0;
      if ((i==0)||(i==(a-1))){
         while(j<a) {
            printf("*");
            j=j+1;
         }
      } else {
         while(j<a) {
            if((j==0)||(j==(a-1)))
               printf("*");
            else
               printf(" ");
            j=j+1;
         }
      }
      printf("\n");
      i=i+1;
   }
}
