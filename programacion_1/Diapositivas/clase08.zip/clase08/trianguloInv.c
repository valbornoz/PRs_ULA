#include "stdio.h"

main() {
   int a,i=0,j=0;
   
   printf("Altura: ");
   scanf("%i",&a);
   
   while(i<a) {
      j=a-i;   
      while(j>0) {
         printf("*");
         j=j-1;
      }
      printf("\n");
      i=i+1;
   }
}
