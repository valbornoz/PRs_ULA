#include "stdio.h"

main(){
   int i;
   int v[5];
   
   for(i=0;i<5;i++){
      printf("Número %i: ",i+1);
      scanf("%i",&v[i]);
   }
   printf("Los números introducidos fueron: ");
   printf("%i %i %i %i %i",v[0],v[1],v[2],v[3],v[4]);
   /*for(i=0;i<5;i++){
      printf("%i ",v[i]);
   }*/
   printf("\n");   
}
