/*
2) Realice un programa en lenguaje C que, dado el número de asteriscos en la diagonal, sea capaz de dibujar V's de la siguiente forma:
Para n=2: 		Para n=3:		Para n=4:
* *			*   *   		*     *
 *	 		 * *     		 *   *
       		  *       	  * *
                			   *
*/
#include "stdio.h"

main() {
   int alto, i=0, j, ancho;
   
   printf("Asterisco en la diagonal?: ");
   scanf("%i",&alto);

   ancho = 2*alto-1;
   i=alto-1;
   while(i>=0) {
      j=0;
      while(j<ancho) {
         if((j==(alto-i-1))||(j==(alto+i-1)))
            printf("*");
         else
            printf(" ");
         j=j+1;         
      }
      printf("\n");
      i=i-1;
   }
}
