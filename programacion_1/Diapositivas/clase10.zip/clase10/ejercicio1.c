/*
1er Examen Parcial
1) Realice un programa en lenguaje C que muestre el resultado de sumar los números impares que hay entre el 1 y el 1000 (Ambos inclusive).
*/
#include "stdio.h"

main() {
   int i,suma=0;
   for(i=1;i<=1000;i=i+1){
      if(i%2!=0)
         suma=suma+i;
   }
   printf("La suma es: %i\n", suma);
}

